/*
 * Dummy file to workaround an automake limitation: if we try to list the
 * file directly, automake will clean up its internal state in both the src/
 * and tests/ subdirs, but only one will succeed.
 */
#include "../src/gdhelpers.c"
